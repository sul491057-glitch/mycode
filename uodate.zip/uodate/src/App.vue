<script setup lang="ts">
</script>

<template>
  <router-view></router-view>
</template>

<style>
#app {
  width: 100%;
  height: 100vh;
}
</style>
